package com.isaanggi.listproduk

data class ProductResponse (
    val products: List<Product>
)