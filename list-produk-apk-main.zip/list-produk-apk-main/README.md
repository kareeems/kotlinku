Aplikasi mobile compose sederhana yang berfungsi untuk mengambil data melalui REST API dan menampilkannya dalam bentuk list. 
